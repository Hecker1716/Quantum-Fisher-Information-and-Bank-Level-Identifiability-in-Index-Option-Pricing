"""Fast checks that the code reproduces key numbers reported in the paper."""
import numpy as np
import pytest
from scipy.stats import norm

from common import PAPER_TABLES, S0, b, bs, load_rho, q, r, read_csv, se, sI, share, sig, vega
from qae import iqae


def test_black_scholes_reproduces_table2():
    """Exact prices in Table 2 come from Black-Scholes with sigma_I = 22.72%.

    The paper reports rounded inputs (r = 2.47%, q = 4.24%); the original run used unrounded
    values, so long-dated puts differ by up to 0.002 index points. Calls agree to 3.5e-4.
    """
    for row in read_csv(PAPER_TABLES / "table2_option_prices.csv"):
        T, K = int(row["T_days"]) / 252, S0 * int(row["K_pct"]) / 100
        assert bs(S0, K, T, sI) == pytest.approx(float(row["call_exact"]), abs=3.5e-4)
        assert bs(S0, K, T, sI, call=False) == pytest.approx(float(row["put_exact"]), abs=2.5e-3)


def test_one_factor_correlation_reproduces_index_vol():
    rho = load_rho()
    off = rho[~np.eye(12, dtype=bool)]
    assert np.allclose(np.diag(rho), 1) and np.allclose(rho, rho.T)
    assert 0.45 < off.min() and off.max() < 0.85            # paper: 0.50-0.82
    Sig = np.diag(sig) @ rho @ np.diag(sig)
    assert np.sqrt(b @ Sig @ b + se**2) == pytest.approx(sI, abs=1e-4)


def test_euler_shares_sum():
    """Euler shares add up to 1 - s_e^2/sigma_I^2 = 0.979."""
    rho = load_rho()
    Sig = np.diag(sig) @ rho @ np.diag(sig)
    s2 = b @ Sig @ b + se**2
    assert np.sum(b * (Sig @ b)) / s2 == pytest.approx(0.979, abs=1e-3)


def test_qfi_shares_reproduced_from_correlation():
    """QFI shares of Table 4 follow from the calibrated R0 (rank-one formula)."""
    rho = load_rho()
    T = 63 / 252
    grad = b * (rho @ (sig * b)) / sI                     # d sigma_I / d sigma_i
    nu = vega(1, 1, T, sig, r, np.array([float(x["dividend_yield"]) for x in read_csv(PAPER_TABLES.parent / "inputs" / "bank_inputs.csv")]))
    Fc = (grad / nu) ** 2
    assert np.allclose(Fc / Fc.sum(), share, atol=2e-3)


def _bins(n=6, w=4.0, T=63 / 252, K=S0):
    m = np.log(S0) + (r - q - .5 * sI**2) * T
    s = sI * np.sqrt(T)
    e = np.linspace(m - w * s, m + w * s, 2**n + 1)
    e += np.log(K) - e[np.argmin(np.abs(e - np.log(K)))]
    z = (e - m) / s
    P = np.diff(norm.cdf(z))
    cm = np.exp(m + .5 * s * s) * np.diff(norm.cdf(z - s)) / P
    return P / P.sum(), cm


def test_grid_error_matches_table_s9():
    """63-day ATM call: grid (truncation) error about 7e-4 at +-4 s.d."""
    p, cm = _bins()
    grid_price = np.exp(-r * 63 / 252) * p @ np.maximum(cm - S0, 0)
    assert 5e-4 < abs(grid_price - bs(S0, S0, 63 / 252, sI)) < 9e-4


@pytest.mark.parametrize("a", [0.05, 0.2, 0.5])
def test_iqae_counts_and_accuracy(a):
    rng = np.random.default_rng(0)
    for _ in range(20):
        est, NA, G, Ns, hw, W = iqae(a, 0.002, 0.05, 500, rng)
        assert NA == 2 * G + Ns                           # Eq. (5)
        assert W >= NA                                    # (2k+1)^2 >= 2k+1
        assert abs(est - a) <= 0.002 + 1e-12 or abs(est - a) <= 3 * hw


def test_rank_one_qfi():
    """Proposition 1: the bank-volatility QFI has rank one."""
    rho = load_rho()
    T = 63 / 252
    m0 = np.log(S0) + (r - q - .5 * sI**2) * T
    e = np.linspace(m0 - 4 * sI * np.sqrt(T), m0 + 4 * sI * np.sqrt(T), 65)

    def probs(sv):
        S = np.diag(sv) @ rho @ np.diag(sv)
        v = np.sqrt(b @ S @ b + se**2)                    # sigma_I(sigma), Eq. (2)
        m = np.log(S0) + (r - q - .5 * v**2) * T
        P = np.diff(norm.cdf((e - m) / (v * np.sqrt(T))))
        return P / P.sum()

    p0, h = probs(sig), 1e-5
    D = np.array([(probs(sig + h * np.eye(12)[i]) - probs(sig - h * np.eye(12)[i])) / (2 * h) for i in range(12)])
    ev = np.sort(np.linalg.eigvalsh((D / p0) @ D.T))[::-1]
    assert ev[1] / ev[0] < 1e-10
