import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

# The one-factor correlation matrix is a derived input; build it if it is missing.
if not (ROOT / "data" / "derived" / "rho_one_factor.npy").exists():
    subprocess.run([sys.executable, str(ROOT / "src" / "calib.py")], check=True)
