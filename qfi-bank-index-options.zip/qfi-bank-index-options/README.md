# Quantum Fisher Information and Bank-Level Identifiability in Index-Option Pricing

Code and data for the paper **"Quantum Fisher Information and Bank-Level Identifiability in
Index-Option Pricing: Aggregation Rank, Contract Selection and Quantum Resource Costs for
EURO STOXX Banks"** by Aditya Narasimha Prasanna.

## What the paper does

We price options on a twelve-bank proxy of the EURO STOXX Banks index (SX7E) with quantum
amplitude estimation (QAE) and ask two questions:

1. **Which bank-level parameters can be learned from the quantum state used for pricing?**
   The quantum Fisher information (QFI) of the loading state has exactly as many directions as
   there are channels ("aggregates") through which the banks enter the index law, and each of
   those directions is something an option price can detect. In the lognormal proxy the rank is
   one: every bank reaches the index option only through the index volatility.
2. **How should option contracts be chosen to learn them on a fixed measurement budget?**
   Strikes never add directions; only maturities that weight the banks differently can. A
   computable ceiling caps every design and measurement, and the payoff that comes closest is a
   digital on a level set of the score. For volatility that is a binary strangle, which captures
   65.2% of the state's information against 17.7% for the best call or put.

On cost, QAE needed about six times fewer queries than plain Monte Carlo, but did not beat
quasi-Monte Carlo and ran far slower on a simulator. All prices are model prices and all quantum
circuits were simulated classically.

<p align="center">
  <img src="figures/png/fig04_mc_simulation.png" width="100%" alt="Monte Carlo simulation of the twelve-bank proxy"><br>
  <em>Figure 4 – simulated index paths, terminal distribution with the 64-bin QAE loading state, and Monte Carlo convergence.</em>
</p>
<p align="center">
  <img src="figures/png/fig14_accuracy_cost.png" width="100%" alt="Accuracy and cost of CMC and QAE"><br>
  <em>Figure 14 – error against cost, cost at matched precision, and the errors of all 24 options.</em>
</p>

## Quick start

```bash
git clone https://github.com/<your-username>/qfi-bank-index-options.git
cd qfi-bank-index-options
python -m pip install -r requirements.txt

./run_all.sh          # or: make all
```

`run_all.sh` runs every step below (about 1 minute on a laptop). On Windows, run the Python
commands one by one:

```bash
python src/calib.py     # 1. one-factor correlation matrix   -> data/derived/rho_one_factor.npy
python src/sims.py      # 2. Monte Carlo + QAE simulations    -> results/simulation_*.{npz,json}
python src/plots.py     # 3. full-width figures 4, 14, 15, 19 -> figures/
python src/proofs.py    # 4. all other figures                -> figures/, results/proof_stats.json
python -m pytest -q tests
```

All randomness uses fixed seeds, so the figures are reproduced exactly.

## Repository layout

```
qfi-bank-index-options/
├── src/
│   ├── common.py                model inputs, paths, Black–Scholes helpers
│   ├── calib.py                 one-factor correlation matrix R0 (Section 4.5)
│   ├── qae.py                   iterative QAE with exact shot statistics
│   ├── sims.py                  classical Monte Carlo and QAE simulations
│   ├── plots.py                 full-width figures (4, 14, 15, 19)
│   └── proofs.py                numerical checks of every claim ("proof graphs")
├── data/
│   ├── inputs/                  market parameters and bank inputs (Tables 1, 4)
│   ├── paper_tables/            results reported in the paper (Tables 2, 5, 6, 7, S21)
│   ├── derived/                 generated correlation matrix
│   └── README.md                data dictionary
├── results/                     simulation outputs and statistics (generated)
├── figures/                     all 21 figures as PDF (generated) + PNG previews
├── tests/                       pytest checks against numbers in the paper
├── run_all.sh, Makefile         one-command reproduction
├── requirements.txt
└── CITATION.cff
```

## Figures and where they come from

"Computed" means the script recomputes the result from the model inputs; "plotted" means it
draws numbers reported in the paper's tables (`data/paper_tables/`).

| Fig. | File | What it shows | Script | Type |
|---|---|---|---|---|
| 1 | `fig01_euler_decomposition` | 12 banks carry 97.9% of index variance | `proofs.py` | computed |
| 2 | `fig02_leave_one_out` | change in σ_I when one bank is removed | `proofs.py` | computed |
| 3 | `fig03_qq_index_law` | the 12-bank simulation gives the lognormal index law | `proofs.py` | computed |
| 4 | `fig04_mc_simulation` | paths, terminal law, CMC convergence | `sims.py` + `plots.py` | computed |
| 5 | `fig05_iqae_cost_counts` | IQAE queries, Grover steps, shots, CX gates | `proofs.py` | computed |
| 6 | `fig06_rank_one_qfi` | Proposition 1: rank-one QFI | `proofs.py` | computed |
| 7 | `fig07_sensitivity_bound` | Proposition 2 for calls, puts, digitals | `proofs.py` | computed |
| 8 | `fig08_bound_random_payoffs` | Proposition 2 on 6,000 random payoffs | `proofs.py` | computed |
| 9 | `fig09_rank_vs_qubits_equivalence` | Proposition 3 and Corollary 2 | `proofs.py` | computed* |
| 10 | `fig10_iqae_information_factor` | Proposition 4(iii) | `proofs.py` | computed |
| 11 | `fig11_contract_information` | Proposition 4(i), all 72 contracts | `proofs.py` | computed |
| 12 | `fig12_crlb_recovery` | Proposition 5: estimator vs Cramér–Rao bound | `proofs.py` | computed |
| 13 | `fig13_binary_strangle` | Proposition 6: best payoff | `proofs.py` | computed |
| 14 | `fig14_accuracy_cost` | (a, b) error and cost; (c) Table 2 errors | `sims.py` + `plots.py` | computed / plotted |
| 15 | `fig15_banks_forecast` | QFI shares (Table 4) and forecasts (S21) | `plots.py` | plotted |
| 16 | `fig16_grid_error` | grid error vs truncation width and qubits | `proofs.py` | computed |
| 17 | `fig17_qfi_vs_euler` | QFI share vs Euler share and loading | `proofs.py` | computed |
| 18 | `fig18_forecast_accuracy` | Table 5 | `proofs.py` | plotted |
| 19 | `fig19_robustness_design` | Tables 6 and 7 | `plots.py` | plotted |
| 20 | `fig20_identifiability` | Cramér–Rao s.d. vs number of observations | `proofs.py` | computed from Table 6 |
| 21 | `fig21_noise` | circuit success probability under gate noise | `proofs.py` | computed |

\* The correlation-regime model C1 in Fig. 9 uses illustrative parameters (stress probability
25%, stress shift φ = 0.4), so its eigenvalue ratio (5.6×10⁻⁷) differs from Table 6 (1.0×10⁻⁶);
the rank result does not depend on them.

## Scope: what is and is not in this repository

**Included and reproducible here**
- The full twelve-bank index model (Eqs. 1–3) with the published inputs.
- Classical Monte Carlo on the 13-dimensional bank simulation, plus antithetic/control-variate
  and randomised quasi-Monte Carlo baselines.
- Iterative QAE (IQAE) with exact shot statistics. Shots of `Q^k A|0>` are drawn from their
  exact Bernoulli law, which reproduces the IQAE schedule, intervals and query counts without a
  gate-level simulator.
- Numerical checks of Propositions 1–6 and Corollary 2, and every figure in the paper.

**Not included** (from the original research pipeline)
- Daily bank and index prices for 2018–2026 (not redistributable) and the estimation step that
  produced the inputs in `data/inputs/`.
- Gate-level Qiskit / Qiskit Aer circuits (the QAE column of Table 2 and the circuit depth and
  gate counts in Section 4.2).
- The extended-model experiments (A1–D2), the contract-design optimiser, the HAR-X forecasting
  model, and the supplementary tables (S1–S33). Their reported results are in
  `data/paper_tables/` and are plotted, not recomputed.

**Known small difference.** The paper states rounded inputs (r = 2.47%, q = 4.24%). With these,
Black–Scholes reproduces the exact call prices in Table 2 to within 3.5×10⁻⁴ index points and the
puts to within 0.002; the original run used unrounded values. The test suite allows for this.

## Requirements

- Python 3.10 or later, with `numpy`, `scipy`, `matplotlib` and `pytest` (see `requirements.txt`).
  Tested with Python 3.13, numpy 2.5.3, scipy 1.18.1 and matplotlib 3.11.2.

## Citation

See [`CITATION.cff`](CITATION.cff), or cite:

> A. N. Prasanna, "Quantum Fisher Information and Bank-Level Identifiability in Index-Option
> Pricing: Aggregation Rank, Contract Selection and Quantum Resource Costs for EURO STOXX Banks,"
> 2026.

## Contact

Aditya Narasimha Prasanna – adityanarasimhaprasanna@gmail.com
