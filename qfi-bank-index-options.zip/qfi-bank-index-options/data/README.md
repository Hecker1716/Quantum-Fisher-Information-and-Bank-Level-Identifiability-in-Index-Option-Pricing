# Data

All numbers the code needs are in this folder, so nothing is hard-coded in the scripts.

## `inputs/` – model inputs (valuation date 20 October 2026)

| File | Contents | Source in the paper |
|---|---|---|
| `market_parameters.json` | SX7E close `S0 = 38.12`, index volatility `sigma_I = 22.72%`, ECB deposit rate 2.50% (the model uses `r = ln 1.025 = 2.47%`), dividend yield `q = 4.24%`, residual volatility `s_e = 3.29%`, `R^2 = 0.990`, realised index volatility 22.71%, 252-session window, index ISIN | Sections 3 and 4 |
| `bank_inputs.csv` | One row per bank: SX7E membership, volatility `sigma`, ridge loading `loading_b`, dividend yield; plus the Table 4 columns `qfi_share`, `F_c_ii`, `atm_call_pct_spot`, `elasticity`, `corr_option_changes` | Tables 1 and 4 |

## `paper_tables/` – results reported in the paper

These come from the original research pipeline (see "Scope" in the main README). The plotting
scripts read them; they are not recomputed here.

| File | Contents | Paper |
|---|---|---|
| `table2_option_prices.csv` | 24 SX7E options (4 maturities × 3 strikes × call/put): exact, CMC and QAE prices, absolute errors, QAE oracle calls | Table 2 |
| `table5_forecast_accuracy.csv` | Out-of-sample HAR-X accuracy by horizon: n, RMSE (log), MAPE (%), 90% coverage | Table 5 |
| `table6_qfi_rank_by_model.csv` | Rank structure of the bank-volatility QFI for models M0–D2 (`<1e-15` = round-off floor) | Table 6 |
| `table7_measurement_plans.csv` | Information per shot along the weakest direction, % of the ceiling, for each plan (A2 as a low–high range over seeds) | Table 7 |
| `forecast_63d.csv` | Model-implied 3-month ATM call values (% of spot): now, 63-session forecast, 90% interval | Supplementary Table S21 (Fig. 15b) |

## `derived/` – generated inputs

| File | Made by | Contents |
|---|---|---|
| `rho_one_factor.npy` | `src/calib.py` | 12×12 one-factor correlation matrix `R0` (`rho_ij = beta_i beta_j`), calibrated so that it reproduces `sigma_I = 22.72%` and the QFI shares of Table 4 (Section 4.5). Correlations 0.48–0.81. |

## Not included

The daily closing prices of the twelve banks and of the SX7E index (2018–2026) are not
redistributed. The parameters estimated from them are provided in `inputs/`.
