#!/usr/bin/env bash
# Reproduce every figure and result, then run the tests.
set -euo pipefail
cd "$(dirname "$0")"
PY=${PY:-python3}
$PY src/calib.py      # one-factor correlation matrix  -> data/derived/
$PY src/sims.py       # Monte Carlo + QAE simulations  -> results/
$PY src/plots.py      # full-width figures 4, 14, 15, 19 -> figures/
$PY src/proofs.py     # all other figures ("proof graphs") -> figures/
$PY -m pytest -q tests
