"""Iterative quantum amplitude estimation (IQAE, Grinko et al. 2021) with exact shot statistics.

Measuring Q^k A|0> gives outcome 1 with probability sin^2((2k+1) theta), where a = sin^2(theta).
Instead of simulating the circuit gate by gate we draw the shots from that exact Bernoulli law,
which reproduces the IQAE schedule, confidence intervals and query counts. Clopper-Pearson intervals.

iqae(a, eps, alpha, shots, rng) -> (estimate, N_A, G, N_s, half_width, W)
  N_A  calls to A or A^dagger  = sum_j s_j (2 k_j + 1)
  G    Grover applications     = sum_j s_j k_j
  N_s  shots                   = sum_j s_j
  W    Fisher weight           = sum_j s_j (2 k_j + 1)^2   (Proposition 4(iii))
"""
import numpy as np
from scipy.stats import beta as betad
def cp(k, n, alpha):
    lo = 0.0 if k == 0 else betad.ppf(alpha/2, k, n-k+1)
    hi = 1.0 if k == n else betad.ppf(1-alpha/2, k+1, n-k)
    return lo, hi

def find_next_k(k, up, th, min_ratio=2):
    tl, tu = th
    old = 4*k+2
    maxs = int(1/(2*(tu-tl)))
    s = maxs - (maxs-2) % 4
    while s >= min_ratio*old:
        tmin = s*tl - int(s*tl); tmax = s*tu - int(s*tu)
        if tmin <= tmax <= .5 and tmin <= .5: return (s-2)//4, True
        if tmax >= .5 and tmax >= tmin >= .5: return (s-2)//4, False
        s -= 4
    return int(k), up

def iqae(a, eps, alpha, shots, rng):
    th_true = np.arcsin(np.sqrt(a))
    maxr = int(np.log(2*np.pi/8/eps)/np.log(2)) + 1
    th = [0.0, 0.25]; k = 0; up = True
    NA = 0; G = 0; Ns = 0; W = 0
    prev_k = None; agg1 = 0; aggn = 0
    while th[1]-th[0] > eps/np.pi:
        k, up = find_next_k(k, up, th)
        ones = rng.binomial(shots, np.sin((2*k+1)*th_true)**2)
        NA += shots*(2*k+1); G += shots*k; Ns += shots; W += shots*(2*k+1)**2
        if k == prev_k: agg1 += ones; aggn += shots
        else: agg1, aggn = ones, shots
        prev_k = k
        amin, amax = cp(agg1, aggn, alpha/maxr)
        sc = 4*k+2
        if up:
            tmin = np.arccos(1-2*amin)/(2*np.pi); tmax = np.arccos(1-2*amax)/(2*np.pi)
        else:
            tmin = 1-np.arccos(1-2*amax)/(2*np.pi); tmax = 1-np.arccos(1-2*amin)/(2*np.pi)
        th = [(int(sc*th[0])+tmin)/sc, (int(sc*th[1])+tmax)/sc]
    al, au = np.sin(2*np.pi*th[0])**2, np.sin(2*np.pi*th[1])**2
    return (al+au)/2, NA, G, Ns, (au-al)/2, W

