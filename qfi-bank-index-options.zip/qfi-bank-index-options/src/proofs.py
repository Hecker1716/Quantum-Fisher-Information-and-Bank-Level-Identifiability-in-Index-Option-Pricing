"""Numerical checks ("proof graphs") for the claims of the paper - the column-width figures.

Each figure recomputes a claim from the model (rank-one QFI, payoff bound, aggregation rank,
contract information, best payoff, IQAE information, Cramer-Rao recovery, grid error, Euler
shares, identifiability, noise, cost formulas, the lognormal index law).
Writes the remaining figures/figNN_*.pdf and results/proof_stats.json.
"""
import json

import matplotlib
import numpy as np
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.optimize import brentq
from scipy.stats import kstest, norm, spearmanr
from common import FIGURES, PAPER_TABLES, RESULTS, S0, b, banks, bs, constituent, load_rho, q, qi, r, read_csv, se, sI, share, sig, vega
from qae import iqae

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["STIXGeneral", "DejaVu Serif"], "mathtext.fontset": "stix",
    "font.size": 7.5, "axes.titlesize": 7.8, "axes.labelsize": 7.5, "legend.fontsize": 6.3,
    "xtick.labelsize": 6.6, "ytick.labelsize": 6.6, "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "legend.frameon": False, "savefig.bbox": "tight", "savefig.pad_inches": 0.02})
BLUE, RED, GREEN, PURPLE, GRAY, INK, ORANGE = "#2463a6", "#c8372d", "#5b8c2a", "#7b4fa0", "#8a8a8a", "#222222", "#d98b1e"
CW = 3.45
rho = load_rho()
Sig = np.diag(sig) @ rho @ np.diag(sig)
stats = {}
def tag(ax, s): ax.set_title(s, loc="left", fontweight="bold")
def save(fig, name): fig.savefig(FIGURES / (name + ".pdf")); plt.close(fig)

def sigmaI(sv, R=rho):
    S = np.diag(sv) @ R @ np.diag(sv); return np.sqrt(b @ S @ b + se**2)
def edges_for(T, n=6, w=4.0, K=None):
    m = np.log(S0)+(r-q-.5*sI**2)*T; s = sI*np.sqrt(T)
    e = np.linspace(m-w*s, m+w*s, 2**n+1)
    if K is not None:
        j = np.argmin(np.abs(e-np.log(K))); e = e+(np.log(K)-e[j])
    return e
def probs(e, T, v):
    m = np.log(S0)+(r-q-.5*v**2)*T; s = v*np.sqrt(T)
    P = np.diff(norm.cdf((e-m)/s)); return P/P.sum()
def condmean(e, T, v=sI):
    m = np.log(S0)+(r-q-.5*v**2)*T; s = v*np.sqrt(T)
    z = (e-m)/s; return np.exp(m+.5*s*s)*np.diff(norm.cdf(z-s))/np.diff(norm.cdf(z))
def fisher(pfun, theta, h):
    p0 = pfun(theta); D = []
    for i in range(len(theta)):
        tp = theta.copy(); tm = theta.copy(); tp[i] += h; tm[i] -= h
        D.append((pfun(tp)-pfun(tm))/(2*h))
    D = np.array(D); return (D/p0) @ D.T
def gI(e, T, h=1e-5):  # Fisher information of bins wrt sigma_I
    d = (probs(e, T, sI+h)-probs(e, T, sI-h))/(2*h); return np.sum(d*d/probs(e, T, sI))
def eff(f, e, T, h=1e-5):  # per-unit-risk sensitivity relative to QFI along sigma_I
    p = probs(e, T, sI); d = (probs(e, T, sI+h)-probs(e, T, sI-h))/(2*h)
    return (d@f)**2/(p@f**2-(p@f)**2)/gI(e, T)
def pershot(f, e, T, h=1e-5):  # Bernoulli information of a normalised payoff relative to QFI
    f = (f-f.min())/(f.max()-f.min()); p = probs(e, T, sI); d = (probs(e, T, sI+h)-probs(e, T, sI-h))/(2*h)
    a = p@f; return (d@f)**2/(a*(1-a))/gI(e, T)

# ===== P1: Euler decomposition (intro / Sec 3) =====
s2 = b@Sig@b+se**2; RC = b*(Sig@b)/s2
o = np.argsort(-RC)
fig, ax = plt.subplots(figsize=(CW, 1.85))
ax.bar(range(12), 100*RC[o], color=[BLUE if constituent[i] else GRAY for i in o], width=0.7)
ax.bar(12, 100*se**2/s2, color="white", edgecolor=INK, hatch="////", lw=0.5, width=0.7)
ax2 = ax.twinx(); cum = np.cumsum(np.r_[100*RC[o], 100*se**2/s2])
ax2.plot(range(13), cum, "o-", color=RED, ms=2.5, lw=0.9); ax2.set_ylim(0, 105); ax2.set_ylabel("cumulative (%)", color=RED)
ax2.spines["right"].set_visible(True); ax2.tick_params(axis="y", colors=RED)
short = {"Lloyds Banking Group": "Lloyds", "Banco Santander": "Santander", "Intesa Sanpaolo": "Intesa", "Société Générale": "SocGen", "Deutsche Bank": "Deutsche", "BNP Paribas": "BNP", "UBS Group": "UBS", "Commerzbank": "Commerz."}
ax.set_xticks(range(13)); ax.set_xticklabels([short.get(banks[i], banks[i]) for i in o]+["residual"], rotation=60, ha="right", fontsize=6)
ax.set_ylabel("share of index variance (%)")
ax.text(0.98, 0.55, f"12 banks: {100*RC.sum():.1f}%\nresidual: {100*se**2/s2:.1f}%", transform=ax.transAxes, ha="right", fontsize=6.5)
save(fig, "fig01_euler_decomposition")
stats["euler_sum"] = RC.sum(); stats["socgen_euler"] = RC[6]

# ===== P2: leave-one-out sigma_I (Sec 3) =====
loo = []
for i in range(12):
    bb = b.copy(); bb[i] = 0; loo.append(100*(np.sqrt(s2)-np.sqrt(bb@Sig@bb+se**2)))
loo = np.array(loo); o = np.argsort(loo)
fig, ax = plt.subplots(figsize=(CW, 1.75))
ax.barh(range(12), loo[o], color=BLUE, height=0.65)
for k, i in enumerate(o): ax.text(loo[i]+0.05, k, f"{loo[i]:.2f}", va="center", fontsize=5.8)
ax.set_yticks(range(12)); ax.set_yticklabels([banks[i] for i in o], fontsize=6)
ax.set_xlabel("drop in $\\sigma_I$ when the bank is removed (vol. points)"); ax.set_xlim(0, 3.8)
save(fig, "fig02_leave_one_out")
stats["loo_min"], stats["loo_max"] = loo.min(), loo.max()

# ===== P3: Proposition 1, rank-one QFI =====
T = 63/252; e = edges_for(T)
pf = lambda sv: probs(e, T, sigmaI(sv))
F = fisher(pf, sig.copy(), 1e-5)
nu = vega(1, 1, T, sig, r, qi); Fc = F/np.outer(nu, nu)
ev = np.sort(np.linalg.eigvalsh(F))[::-1]; ratio = np.abs(ev)/ev[0]
fig, ax = plt.subplots(1, 2, figsize=(CW, 1.65), gridspec_kw=dict(wspace=0.45, width_ratios=[1.1, 1]))
a = ax[0]
a.semilogy(range(1, 13), np.maximum(ratio, 1e-20), "o", color=RED, ms=3)
a.axhspan(1e-21, 1e-8, color=GRAY, alpha=0.15, lw=0); a.text(6.5, 1e-10, "below tolerance $10^{-8}$", ha="center", fontsize=5.8, color="#555")
a.set_xlabel("eigenvalue number"); a.set_ylabel("$\\lambda_k/\\lambda_1$"); a.set_ylim(1e-21, 10); a.set_xticks([1, 4, 8, 12])
tag(a, "(a) Spectrum of $F^\\sigma$")
a = ax[1]
C = Fc/np.sqrt(np.outer(np.diag(Fc), np.diag(Fc)))
im = a.imshow(C, vmin=0.99, vmax=1.0, cmap="Blues"); a.set_xticks([]); a.set_yticks([])
a.set_xlabel("bank $j$"); a.set_ylabel("bank $i$")
cb = fig.colorbar(im, ax=a, fraction=0.046, pad=0.04, ticks=[0.99, 0.995, 1.0]); cb.ax.tick_params(labelsize=5.5)
tag(a, "(b) $F^c_{ij}/\\sqrt{F^c_{ii}F^c_{jj}}$")
save(fig, "fig06_rank_one_qfi")
g63 = gI(e, T)
stats.update(rank1_l2=float(ratio[1]), corr_min=float(C.min()), g63=g63, g_cont=T+2/sI**2,
             share_err=float(np.max(np.abs(np.diag(Fc)/np.trace(Fc)-share))))

# ===== P4: Proposition 2, payoff sensitivity vs QFI bound =====
cm = condmean(e, T); z = (e[:-1]+e[1:])/2; zc = (z-(np.log(S0)+(r-q-.5*sI**2)*T))/(sI*np.sqrt(T))
Ks = np.linspace(0.8, 1.2, 41)
ec = [eff(np.maximum(cm-k*S0, 0), e, T) for k in Ks]
ep = [eff(np.maximum(k*S0-cm, 0), e, T) for k in Ks]
ed = [eff((cm > k*S0).astype(float), e, T) for k in Ks]
p0 = probs(e, T, sI); d0 = (probs(e, T, sI+1e-5)-probs(e, T, sI-1e-5))/2e-5; score = d0/p0
e_score = eff(score, e, T)
cs = np.linspace(0.3, 3, 60); est = [eff((np.abs(zc) > c).astype(float), e, T) for c in cs]
fig, ax = plt.subplots(figsize=(CW, 1.85))
ax.plot(100*Ks, np.sqrt(ec), color=BLUE, lw=1.1, label="call")
ax.plot(100*Ks, np.sqrt(ep), color=BLUE, lw=1.1, ls="--", label="put")
ax.plot(100*Ks, np.sqrt(ed), color=ORANGE, lw=1.1, label="digital call")
ax.axhline(np.sqrt(max(est)), color=RED, lw=1, ls="-.", label=f"best binary strangle ({100*np.sqrt(max(est)):.0f}%)")
ax.axhline(e_score, color=INK, lw=1, label="score payoff = bound (100%)")
i100 = np.argmin(np.abs(Ks-1))
ax.plot(100, np.sqrt(ec[i100]), "o", color=BLUE, ms=3); ax.annotate("ATM call: 46%", (100, np.sqrt(ec[i100])), (86, 0.06), fontsize=6, arrowprops=dict(arrowstyle="-", lw=0.5))
ax.set_xlabel("strike (% of spot), 63-day contracts"); ax.set_ylabel("sensitivity / QFI bound")
ax.set_ylim(0, 1.5); ax.set_yticks([0, .25, .5, .75, 1]); ax.legend(loc="upper center", ncol=3, fontsize=5.7)
save(fig, "fig07_sensitivity_bound")
i100 = np.argmin(np.abs(Ks-1))
stats.update(eff_atm_call=ec[i100], ratio_atm_call=np.sqrt(ec[i100]), eff_atm_dig=ed[i100], ratio_atm_dig=np.sqrt(ed[i100]), eff_score=e_score)

# ===== P5: Proposition 3, rank vs number of qubits; C1 regimes =====
pi_s, phi = 0.25, 0.4
R1 = rho+phi*(np.ones((12, 12))-rho)
def pC1(sv, e, T):
    return (1-pi_s)*probs(e, T, sigmaI(sv, rho))+pi_s*probs(e, T, sigmaI(sv, R1))
ns = np.arange(1, 11); l2M, l2C = [], []
for n in ns:
    e_n = edges_for(T, n=n)
    for fun, lst in ((lambda sv: probs(e_n, T, sigmaI(sv)), l2M), (lambda sv: pC1(sv, e_n, T), l2C)):
        FF = fisher(fun, sig.copy(), 1e-4); w_ = np.sort(np.abs(np.linalg.eigvalsh(FF)))[::-1]
        lst.append(max(w_[1]/w_[0], 1e-20))
# observational equivalence: move HSBC up, Santander down along constant sigma_I
sA = sig.copy(); sB = sig.copy(); sB[0] += 0.03
sB[7] = brentq(lambda x: sigmaI(np.r_[sB[:7], x, sB[8:]])-sigmaI(sA), 0.05, 0.6)
sC = sig.copy(); dv = sB-sA; sC[0] += np.linalg.norm(dv)  # same size move, off the level set
pA, pB, pCc = probs(e, T, sigmaI(sA)), probs(e, T, sigmaI(sB)), probs(e, T, sigmaI(sC))
fig, ax = plt.subplots(1, 2, figsize=(CW, 1.7), gridspec_kw=dict(wspace=0.5))
a = ax[0]
a.semilogy(ns, l2M, "o-", color=INK, ms=2.8, lw=0.9, label="M0 (one aggregate)")
a.semilogy(ns, l2C, "s-", color=RED, ms=2.8, lw=0.9, label="C1 (two regimes)")
a.axhline(1e-8, color=GRAY, lw=0.6, ls="--"); a.text(10, 2e-8, "tolerance", fontsize=5.6, color="#555", ha="right")
a.set_xlabel("qubits $n$ ($2^n$ bins)"); a.set_ylabel("$\\lambda_2/\\lambda_1$"); a.set_ylim(1e-20, 1e-2)
a.legend(loc="lower right", fontsize=5.6); tag(a, "(a) Rank vs grid size")
a = ax[1]
a.semilogy(np.abs(pA-pB)+1e-17, color=BLUE, lw=1.4, label="same $\\sigma_I$ (exactly 0)")
a.semilogy(np.abs(pA-pCc)+1e-20, color=RED, lw=0.9, label="different $\\sigma_I$")
a.set_xlabel("bin $k$"); a.set_ylabel("$|p_k(\\theta_1)-p_k(\\theta_2)|$"); a.set_ylim(3e-18, 1e-1)
a.legend(loc="center right", fontsize=5.6); tag(a, "(b) Equivalence")
save(fig, "fig09_rank_vs_qubits_equivalence")
stats.update(C1_l2_n6=l2C[5], C1_l2_n1=l2C[0], M0_l2max=max(l2M), equiv_maxdiff=float(np.abs(pA-pB).max()), off_maxdiff=float(np.abs(pA-pCc).max()),
             equiv_sB=(sB[0], sB[7]))

# ===== P6: Proposition 4(i), every contract below its maturity's QFI =====
fig, ax = plt.subplots(figsize=(CW, 1.8))
Kk = np.linspace(0.8, 1.2, 9); best = 0
for d_, c_ in zip((21, 63, 126, 252), (GREEN, BLUE, PURPLE, RED)):
    Tm = d_/252; em = edges_for(Tm); cmm = condmean(em, Tm)
    rc = [pershot(np.maximum(cmm-k*S0, 0), em, Tm) for k in Kk]; rp = [pershot(np.maximum(k*S0-cmm, 0), em, Tm) for k in Kk]
    ax.plot(100*Kk, rc, "o-", color=c_, ms=2.5, lw=0.9, label=f"{d_} d")
    ax.plot(100*Kk, rp, "s--", color=c_, ms=2.3, lw=0.8, mfc="white")
    best = max(best, max(rc), max(rp))
ax.axhline(1, color=INK, lw=0.9); ax.text(81, 0.93, "QFI of the maturity's state (ceiling)", fontsize=6, va="top")
ax.set_ylim(0, 1.05); ax.set_xlabel("strike (% of spot); solid = call, dashed = put"); ax.set_ylabel("per-shot information / QFI")
ax.legend(loc="center right", ncol=2, fontsize=5.8)
save(fig, "fig11_contract_information")
stats["contract_best_ratio"] = best

# ===== P7: Proposition 6, binary strangle efficiency =====
cc = np.linspace(0.2, 3.2, 300)
P = 2*(1-norm.cdf(cc)); eta = (2*cc*norm.pdf(cc))**2/(2*P*(1-P))
T252 = 1.0; e252 = edges_for(T252); z252 = (e252[:-1]+e252[1:])/2
zc252 = (z252-(np.log(S0)+(r-q-.5*sI**2)*T252))/sI
cs2 = np.linspace(0.4, 3.0, 27); pts = [pershot((np.abs(zc252) > c).astype(float), e252, T252) for c in cs2]
cm252 = condmean(e252, T252)
bestvan = max(max(pershot(np.maximum(cm252-k*S0, 0), e252, T252), pershot(np.maximum(k*S0-cm252, 0), e252, T252)) for k in np.linspace(.8, 1.2, 9))
fig, ax = plt.subplots(figsize=(CW, 1.75))
ax.plot(cc, eta, color=INK, lw=1.1, label="theory, Gaussian scale")
ax.plot(cs2, pts, "o", color=RED, ms=2.6, label="computed on the 252-day grid")
ax.axhline(bestvan, color=BLUE, ls="--", lw=0.9, label=f"best call/put, 252 d ({100*bestvan:.0f}%)")
ax.axvline(1.48, color=GRAY, lw=0.6, ls=":"); ax.annotate("$c^*=1.48$, $\\eta^*=0.652$", (1.48, 0.652), (1.8, 0.75), fontsize=6.3, arrowprops=dict(arrowstyle="-", lw=0.5))
ax.set_xlabel("strangle threshold $c$ (standard deviations)"); ax.set_ylabel("per-shot information / QFI")
ax.set_ylim(0, 0.85); ax.legend(loc="lower center", fontsize=5.9)
save(fig, "fig13_binary_strangle")
stats.update(eta_max=float(eta.max()), c_star=float(cc[np.argmax(eta)]), strangle_grid_max=float(max(pts)), bestvan252=bestvan)

# ===== P8: Proposition 4(iii), IQAE information factor =====
eps = np.geomspace(0.02, 0.0005, 8)
fig, ax = plt.subplots(figsize=(CW, 1.7))
fac = {}
for a_, c_ in ((0.05, GREEN), (0.2, BLUE), (0.5, RED)):
    v = []
    for ee in eps:
        rr = np.random.default_rng(int(ee*1e6)+int(a_*100))
        res = [iqae(a_, ee, .05, 500, rr) for _ in range(40)]
        v.append(np.mean([x[5] for x in res])/np.mean([x[1] for x in res]))
    fac[a_] = v
    ax.loglog(eps, v, "o-", color=c_, ms=2.6, lw=0.9, label=f"amplitude $a$ = {a_}")
ax.axhline(1, color=INK, lw=0.8, ls="--"); ax.text(0.015, 1.25, "plain sampling", fontsize=6)
ax.invert_xaxis(); ax.set_xlabel("IQAE target $\\varepsilon$"); ax.set_ylabel("information per query\n($E[W]/E[N_A]$)")
ax.legend(loc="upper left", fontsize=5.9)
save(fig, "fig10_iqae_information_factor")
stats["iqae_factor"] = {str(k): [float(x) for x in v] for k, v in fac.items()}

# ===== P9: Proposition 5, estimator reaches the Cramer-Rao bound (M0) =====
f_s = (np.abs(zc252) > 1.48).astype(float)
sgrid = np.linspace(0.12, 0.36, 4001); agrid = np.array([probs(e252, T252, v)@f_s for v in sgrid])
s_true = sI+0.01; a_true = probs(e252, T252, s_true)@f_s
da = (probs(e252, T252, s_true+1e-5)@f_s-probs(e252, T252, s_true-1e-5)@f_s)/2e-5
I1 = da**2/(a_true*(1-a_true)); gq = gI(e252, T252)
Ns = np.geomspace(1e3, 1e6, 7).astype(int); rm = []
rng = np.random.default_rng(3)
for N in Ns:
    x = rng.binomial(N, a_true, 2000)/N
    sh = np.interp(x, agrid, sgrid); rm.append(100*np.sqrt(np.mean((sh-s_true)**2)))
rm = np.array(rm); crlb = 100/np.sqrt(Ns*I1); qfl = 100/np.sqrt(Ns*gq)
fig, ax = plt.subplots(figsize=(CW, 1.75))
ax.loglog(Ns, rm, "o", color=RED, ms=3.2, label="simulated estimator (2,000 runs)")
ax.loglog(Ns, crlb, color=INK, lw=1, label="Cramér–Rao bound of the contract")
ax.loglog(Ns, qfl, color=BLUE, lw=1, ls="--", label="QFI floor (Prop. 5(ii), any design)")
ax.axhline(1, color=GRAY, lw=0.6, ls=":"); ax.text(1.1e3, 1.1, "1 vol. point", fontsize=5.8, color="#555")
ax.set_xlabel("shots $N$ (binary strangle, 252 d)"); ax.set_ylabel("RMSE of $\\hat\\sigma_I$ (vol. points)")
ax.legend(loc="upper right", fontsize=5.9)
save(fig, "fig12_crlb_recovery")
stats.update(rmse_over_crlb=[float(x) for x in rm/crlb], strangle_frac=I1/gq)

# ===== P10: grid error vs truncation width and qubits =====
ws = np.linspace(3, 5, 9)
fig, ax = plt.subplots(figsize=(CW, 1.7))
exc, exp_ = bs(S0, S0, T, sI), bs(S0, S0, T, sI, call=False)
for n_, c_ in zip((4, 5, 6, 7, 8), (GREEN, BLUE, INK, PURPLE, RED)):
    errc, errp = [], []
    for w_ in ws:
        ee = edges_for(T, n=n_, w=w_, K=S0); pp = probs(ee, T, sI); cmw = condmean(ee, T)
        dsc = np.exp(-r*T)
        errc.append(abs(dsc*pp@np.maximum(cmw-S0, 0)-exc)); errp.append(abs(dsc*pp@np.maximum(S0-cmw, 0)-exp_))
    ax.semilogy(ws, errc, "-", color=c_, lw=0.9+0.4*(n_ == 6), label=f"$n$ = {n_}")
    ax.semilogy(ws, errp, "--", color=c_, lw=0.8)
    if n_ == 6: stats["grid_err_n6"] = dict(zip([float(x) for x in ws], zip(errc, errp)))
ax.set_xlabel("grid half-width (standard deviations)"); ax.set_ylabel("grid error (index points)")
ax.text(4.95, 3e-2, "solid: ATM call\ndashed: ATM put", fontsize=5.8, ha="right", va="top")
ax.legend(loc="lower left", ncol=2, fontsize=5.6)
save(fig, "fig16_grid_error")

# ===== P11: QFI share vs Euler share and squared loading =====
eul = RC/RC.sum(); bl = b**2/np.sum(b**2)
fig, ax = plt.subplots(figsize=(CW, 1.85))
ax.loglog(100*eul, 100*share, "o", color=BLUE, ms=3.2, label=f"Euler share (Spearman {spearmanr(eul, share)[0]:.2f})")
ax.loglog(100*bl, 100*share, "^", color=RED, ms=3.2, label=f"squared loading (Spearman {spearmanr(bl, share)[0]:.2f})")
xx = np.array([0.1, 40]); ax.loglog(xx, xx, color=GRAY, lw=0.6, ls=":")
for nm, dx in (("Société Générale", 1.08), ("Intesa Sanpaolo", 1.08), ("UBS Group", 1.1)):
    i = banks.index(nm); ax.annotate(nm, (100*eul[i], 100*share[i]), (100*eul[i]*dx, 100*share[i]*0.6), fontsize=5.5, color="#444")
ax.set_xlabel("conventional measure (%)"); ax.set_ylabel("QFI share (%)"); ax.set_xlim(0.15, 40); ax.set_ylim(0.15, 40)
ax.legend(loc="upper left", fontsize=5.9)
save(fig, "fig17_qfi_vs_euler")
stats.update(sp_euler=spearmanr(eul, share)[0], sp_load=spearmanr(bl, share)[0])

# ===== P12: forecast accuracy (Table 5) =====
t5 = read_csv(PAPER_TABLES / "table5_forecast_accuracy.csv")   # Table 5
h = np.array([int(x["horizon_days"]) for x in t5]); mape = [float(x["mape_pct"]) for x in t5]; cov = [100*float(x["coverage_90"]) for x in t5]
fig, ax = plt.subplots(figsize=(CW, 1.6))
ax.bar(np.arange(5)-0.18, mape, width=0.36, color=BLUE, label="MAPE (%)")
ax.bar(np.arange(5)+0.18, cov, width=0.36, color=GRAY, label="90% interval coverage (%)")
ax.axhline(90, color=RED, lw=0.8, ls="--"); ax.text(4.45, 92, "target 90%", fontsize=5.8, color=RED, ha="right")
ax.set_xticks(range(5)); ax.set_xticklabels([f"{x} d" for x in h]); ax.set_xlabel("forecast horizon"); ax.set_ylim(0, 115)
ax.legend(loc="upper left", ncol=2, fontsize=5.9)
save(fig, "fig18_forecast_accuracy")

# ===== P13: practical identifiability =====
nobs = np.geomspace(1, 1e12, 200)
fig, ax = plt.subplots(figsize=(CW, 1.8))
ax.loglog(nobs, np.sqrt(4100/nobs), color=INK, lw=1.1, label="first direction ($N_1\\approx4{,}100$)")
ax.fill_between(nobs, np.sqrt(3.7e8/nobs), np.sqrt(4e10/nobs), color=RED, alpha=0.25, lw=0, label="second direction ($N_2$ = $3.7\\times10^8$–$4\\times10^{10}$)")
ax.axhline(1, color=GRAY, lw=0.6, ls="--"); ax.axvline(32, color=BLUE, lw=0.7, ls=":")
ax.text(40, 3e4, "32 windows\n(2018–2026)", fontsize=5.8, color=BLUE)
ax.plot([32, 32], [np.sqrt(4100/32), np.sqrt(3.7e8/32)], "o", color=BLUE, ms=3)
ax.text(45, np.sqrt(4100/32), "≈11", fontsize=6, va="center"); ax.text(45, np.sqrt(3.7e8/32), "≈3,400", fontsize=6, va="center")
ax.text(1e11, 1.3, "1 vol. point", fontsize=5.8, color="#555", ha="right")
ax.set_xlabel("number of independent state copies / windows"); ax.set_ylabel("best possible s.d. (vol. points)")
ax.set_ylim(1e-3, 1e6); ax.legend(loc="upper right", fontsize=5.6)
save(fig, "fig20_identifiability")

# ===== P14: noise =====
k = np.arange(0, 60); cx = 121+366*k
fig, ax = plt.subplots(figsize=(CW, 1.65))
for pe, c_ in ((1e-3, RED), (1e-4, ORANGE), (1e-5, GREEN)):
    ax.semilogy(k, (1-pe)**cx, color=c_, lw=1, label=f"two-qubit error {pe:g}")
ax.axvline(54, color=GRAY, lw=0.6, ls=":"); ax.plot(54, (1-1e-3)**19885, "o", color=RED, ms=3)
ax.annotate("deepest circuit:\n19,885 CX, $\\approx2\\times10^{-9}$", (54, (1-1e-3)**19885), (26, 1e-6), fontsize=6, arrowprops=dict(arrowstyle="-", lw=0.5))
ax.set_xlabel("Grover steps $k$ in one circuit"); ax.set_ylabel("probability of no gate error"); ax.set_ylim(1e-10, 2)
ax.legend(loc="lower left", fontsize=5.9)
save(fig, "fig21_noise")
stats["noise_deepest"] = (1-1e-3)**19885
json.dump(stats, open(RESULTS / "proof_stats.json", "w"), indent=1, default=float)
print(json.dumps(stats, indent=1, default=float))

# ===== Appendix A1: IQAE cost formulas (A1)-(A2) =====
T = 63/252; eK = edges_for(T, K=S0); cmK = condmean(eK, T); gK = np.maximum(cmK-S0, 0)
aK = probs(eK, T, sI)@((gK-gK.min())/(gK.max()-gK.min()))
eps = np.geomspace(0.02, 0.0005, 9); NA, G, Nsh, CX = [], [], [], []; cx002 = []
for ee in eps:
    rr = np.random.default_rng(int(ee*1e7)+9)
    res = [iqae(aK, ee, .05, 500, rr) for _ in range(50)]
    NA.append(np.median([x[1] for x in res])); G.append(np.median([x[2] for x in res])); Nsh.append(np.median([x[3] for x in res]))
    CX.append(np.median([121*x[1]+124*x[2] for x in res]))
    assert all(x[1] == 2*x[2]+x[3] for x in res)
rr = np.random.default_rng(2002); r002 = [iqae(aK, 0.002, .05, 500, rr) for _ in range(200)]
cx002 = np.array([121*x[1]+124*x[2] for x in r002])
fig, ax = plt.subplots(figsize=(CW, 1.75))
ax.loglog(eps, NA, "o-", color=RED, ms=2.6, lw=1, label="$N_A$ (calls to $A$, $A^\\dagger$)")
ax.loglog(eps, G, "s-", color=BLUE, ms=2.4, lw=1, label="$G$ (Grover steps)")
ax.loglog(eps, Nsh, "^-", color=GREEN, ms=2.4, lw=1, label="$N_s$ (shots)")
ax.loglog(eps, CX, "D-", color=INK, ms=2.4, lw=1, label="CX gates, Eq. (A2)")
ax.axvline(0.002, color=GRAY, lw=0.6, ls=":")
ax.text(0.0019, 1.5e3, f"$\\varepsilon$ = 0.002: median\n{np.median(cx002)/1e6:.1f} M CX", fontsize=5.8, ha="right")
ax.invert_xaxis(); ax.set_xlabel("IQAE target $\\varepsilon$"); ax.set_ylabel("count (median of 50 runs)"); ax.set_ylim(3e2, 3e11)
ax.legend(loc="upper left", ncol=2, fontsize=5.6)
save(fig, "fig05_iqae_cost_counts")
stats.update(cx002_p5=np.percentile(cx002, 5), cx002_p95=np.percentile(cx002, 95), cx002_med=np.median(cx002), NA002=np.median([x[1] for x in r002]))

# ===== Appendix A2: inequality (A5) on random payoffs =====
e = edges_for(T); p = probs(e, T, sI); d = (probs(e, T, sI+1e-5)-probs(e, T, sI-1e-5))/2e-5; g = gI(e, T)
rng = np.random.default_rng(1)
def pt(f): return abs(d@f), np.sqrt(g)*np.sqrt(p@f**2-(p@f)**2)
fams = {"random payoffs in [0,1]": rng.random((3000, 64)), "random binary payoffs": (rng.random((3000, 64)) < rng.random((3000, 1))).astype(float)}
cm = condmean(e, T)
fams["calls and puts"] = np.array([np.maximum(cm-k*S0, 0) for k in np.linspace(.7, 1.3, 61)]+[np.maximum(k*S0-cm, 0) for k in np.linspace(.7, 1.3, 61)])
fig, ax = plt.subplots(figsize=(CW, 1.8))
mx = 0
for (nm, F_), c_, m_ in zip(fams.items(), (GRAY, ORANGE, BLUE), ("o", "s", "^")):
    xy = np.array([pt(f) for f in F_ if (p@f**2-(p@f)**2) > 1e-14]); rr_ = xy[:, 0]/xy[:, 1]; mx = max(mx, rr_.max())
    ax.loglog(xy[:, 1], xy[:, 0], m_, color=c_, ms=1.6 if c_ != BLUE else 2.4, alpha=0.6 if c_ != BLUE else 1, lw=0, label=nm)
sx, sy = pt(score)
ax.loglog(sy, sx, "*", color=RED, ms=7, label="score payoff (equality)")
xx = np.geomspace(1e-4, 1e2, 10); ax.loglog(xx, xx, color=INK, lw=0.9, label="bound: $|\\partial V| = \\sqrt{F}\\,\\mathrm{sd}(f)$")
ax.set_xlim(1e-3, 50); ax.set_ylim(1e-6, 50)
ax.set_xlabel("bound $\\sqrt{F}\\,\\mathrm{sd}_p(f)$"); ax.set_ylabel("sensitivity $|\\partial_{\\sigma_I} E_p f|$")
ax.legend(loc="upper left", fontsize=5.6)
save(fig, "fig08_bound_random_payoffs")
stats["A5_max_ratio_random"] = mx
json.dump(stats, open(RESULTS / "proof_stats.json", "w"), indent=1, default=float)
print({k: stats[k] for k in ("cx002_p5", "cx002_p95", "cx002_med", "NA002", "A5_max_ratio_random")})

# ===== Sec 3/4.1: 12-bank simulation gives the lognormal index law =====
rng = np.random.default_rng(42); T = 63/252; Lc = np.linalg.cholesky(rho)
Z = rng.standard_normal((200000, 12)) @ Lc.T
lr = (r-q-.5*sI**2)*T + (sig*np.sqrt(T)*Z)@b + rng.standard_normal(200000)*se*np.sqrt(T)
zs = (lr-(r-q-.5*sI**2)*T)/(sI*np.sqrt(T))
qs = np.linspace(0.0005, 0.9995, 400); emp = np.quantile(zs, qs); th = norm.ppf(qs)
ks = kstest(zs, "norm")
fig, ax = plt.subplots(figsize=(CW, 1.7))
ax.plot(th, emp, "o", color=BLUE, ms=1.8, label="simulated (200,000 draws, 13 normals each)")
ax.plot([-3.6, 3.6], [-3.6, 3.6], color=INK, lw=0.9, label="lognormal law with $\\sigma_I$ = 22.72%")
ax.set_xlabel("theoretical quantile (standard units)"); ax.set_ylabel("simulated quantile")
ax.text(3.5, -3.0, f"simulated $\\sigma_I$ = {100*np.std(lr)/np.sqrt(T):.2f}%\nKS distance = {ks.statistic:.4f}", ha="right", fontsize=6.3)
ax.legend(loc="upper left", fontsize=5.9)
save(fig, "fig03_qq_index_law")
stats.update(qq_sigma=np.std(lr)/np.sqrt(T), ks=ks.statistic, ks_p=ks.pvalue)
print("QQ", stats["qq_sigma"], ks.statistic, ks.pvalue)
