"""Full-width figures of the paper (simulation, accuracy/cost, banks/forecast, robustness/design).

Reads results/simulation_results.npz (from sims.py) and the paper tables in data/paper_tables/.
Writes figures/fig04_mc_simulation.pdf, fig14_accuracy_cost.pdf, fig15_banks_forecast.pdf, fig19_robustness_design.pdf.
"""
import matplotlib
import numpy as np

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from scipy.stats import lognorm

from common import FIGURES, PAPER_TABLES, RESULTS, S0, banks, constituent, q, r, read_csv, sI, share

plt.rcParams.update({
    "font.family": "serif", "font.serif": ["STIXGeneral", "DejaVu Serif"], "mathtext.fontset": "stix",
    "font.size": 8, "axes.titlesize": 8.5, "axes.labelsize": 8, "legend.fontsize": 6.8,
    "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": 0.6, "xtick.major.width": 0.6, "ytick.major.width": 0.6,
    "legend.frameon": False, "savefig.bbox": "tight", "savefig.pad_inches": 0.02})
BLUE, RED, GREEN, PURPLE, GRAY, INK = "#2463a6", "#c8372d", "#5b8c2a", "#7b4fa0", "#8a8a8a", "#222222"
W = 7.25
d = np.load(RESULTS / "simulation_results.npz")
exact = float(d["exact"])
def tag(ax, s): ax.set_title(s, loc="left", fontweight="bold")

# ---------------- Figure 1: Monte Carlo simulation of the index ----------------
fig, ax = plt.subplots(1, 3, figsize=(W, 2.25), gridspec_kw=dict(wspace=0.32))
t = np.arange(64)
a = ax[0]
for i in range(d["paths_show"].shape[1]):
    a.plot(t, d["paths_show"][:, i], lw=0.35, color=BLUE, alpha=0.18)
qq = d["paths_q"]
a.fill_between(t, qq[0], qq[4], color=BLUE, alpha=0.10, lw=0, label="5–95% of 10,000 paths")
a.plot(t, qq[2], color=INK, lw=1.1, label="median path")
a.axhline(S0, color=RED, lw=0.8, ls="--", label="strike (ATM) = 38.12")
a.set_xlabel("trading day"); a.set_ylabel("SX7E proxy level (index points)")
a.set_xlim(0, 63); a.legend(loc="upper left")
tag(a, "(a) Simulated index paths (63 days)")

a = ax[1]
ST = d["ST"]; edges = np.exp(d["edges"]); p = d["p"]
a.hist(ST, bins=60, density=True, color=BLUE, alpha=0.35, label="CMC terminal values")
m = np.log(S0)+(r-q-.5*sI**2)*63/252; s = sI*np.sqrt(63/252)
xs = np.linspace(edges[0], edges[-1], 400)
a.plot(xs, lognorm.pdf(xs, s, scale=np.exp(m)), color=INK, lw=1.0, label="lognormal law ($\\sigma_I$ = 22.72%)")
widths = np.diff(edges)
a.bar(edges[:-1], p/widths, width=widths, align="edge", fill=False, edgecolor=RED, lw=0.5, label="64-bin QAE loading state")
a.axvline(S0, color=RED, lw=0.8, ls="--")
a.set_xlabel("index level at expiry"); a.set_ylabel("density")
a.set_xlim(26, 54); a.set_ylim(0, 0.135); a.legend(loc="upper left", fontsize=6.3)
tag(a, "(b) Terminal distribution")

a = ax[2]
n, mu, se_ = d["run_n"], d["run_mean"], d["run_se"]
a.fill_between(n, mu-1.96*se_, mu+1.96*se_, color=BLUE, alpha=0.18, lw=0, label="95% confidence band")
a.plot(n, mu, color=BLUE, lw=1.0, label="CMC running estimate")
a.axhline(exact, color=INK, lw=0.9, ls="--", label="exact (Black–Scholes)")
a.axvline(1e4, color=GRAY, lw=0.6, ls=":")
a.text(1.15e4, exact-0.42, "$N=10^4$ (Table 2)", fontsize=6.3, color=GRAY)
a.set_xscale("log"); a.set_ylim(exact-0.45, exact+0.65)
a.set_xlabel("number of simulated paths"); a.set_ylabel("call price (index points)")
a.legend(loc="upper right", fontsize=6.3)
tag(a, "(c) Convergence, 63-day ATM call")
fig.savefig(FIGURES / "fig04_mc_simulation.pdf")

# ---------------- Figure 2: accuracy and cost ----------------
fig, ax = plt.subplots(1, 3, figsize=(W, 2.3), gridspec_kw=dict(wspace=0.36))
a = ax[0]
cc, cr, qc, qr = d["c_cost"], d["c_rmse"], d["q_cost"], d["q_rmse"]
a.loglog(cc, cr, "o-", color=BLUE, ms=3, lw=1, label=f"CMC (slope {float(d['sl_c']):.2f})")
a.loglog(qc, qr, "s-", color=RED, ms=3, lw=1, label=f"QAE (slope {float(d['sl_q_head']):.2f}, first six)")
x = np.geomspace(1e2, 3e7, 10)
a.loglog(x, cr[0]*(x/cc[0])**-0.5, ls="--", color=BLUE, lw=0.6, alpha=0.8, label="$N^{-1/2}$ reference")
a.loglog(x, qr[0]*(x/qc[0])**-1.0, ls="--", color=RED, lw=0.6, alpha=0.8, label="$M^{-1}$ reference")
a.set_xlim(80, 2e6); a.set_ylim(3e-4, 0.5)
a.set_xlabel("cost (CMC paths / QAE calls to $A$)"); a.set_ylabel("RMSE (index points)")
a.legend(loc="lower left")
tag(a, "(a) Error against cost")

a = ax[1]
hs = d["hs"]
a.loglog(hs, d["cost_Plain MC"], "o-", color=BLUE, ms=3, lw=1, label="plain MC  ($h^{-2}$)")
a.loglog(hs, d["cost_Antithetic + control variate"], "^-", color=GREEN, ms=3, lw=1, label="antithetic + control variate ($h^{-2}$)")
a.loglog(d["qsweep_hw"][1:], d["qsweep_na"][1:], "s", color=RED, ms=3)
a.loglog(hs, d["cost_QAE (IQAE)"], "-", color=RED, lw=1, label="QAE / IQAE  ($h^{-1}$)")
a.step(hs, d["cost_Randomised QMC (1-D)"], where="mid", color=PURPLE, lw=1, label="randomised QMC, 1-D")
a.set_xlim(0.012, 0.0008); a.set_ylim(2e2, 3e9)
a.set_xlabel("target 95% half-width $h$ (index points)"); a.set_ylabel("samples or queries needed")
a.legend(loc="upper left", fontsize=6.0)
tag(a, "(b) Cost at matched precision")

a = ax[2]
rows = read_csv(PAPER_TABLES / "table2_option_prices.csv")   # Table 2
lab = [f"{x['T_days']}/{x['K_pct']}" for x in rows]
cmc_c = [float(x["call_cmc_abs_err"]) for x in rows]; qae_c = [float(x["call_qae_abs_err"]) for x in rows]
cmc_p = [float(x["put_cmc_abs_err"]) for x in rows]; qae_p = [float(x["put_qae_abs_err"]) for x in rows]
xi = np.arange(len(rows))
a.semilogy(xi-0.12, cmc_c, "o", color=BLUE, ms=3.2, label="CMC, call")
a.semilogy(xi+0.12, cmc_p, "o", mfc="white", color=BLUE, ms=3.2, label="CMC, put")
a.semilogy(xi-0.12, qae_c, "s", color=RED, ms=3.2, label="QAE, call")
a.semilogy(xi+0.12, qae_p, "s", mfc="white", color=RED, ms=3.2, label="QAE, put")
for v in (2.5, 5.5, 8.5): a.axvline(v, color=GRAY, lw=0.4, ls=":")
a.set_xticks(xi); a.set_xticklabels([x.split("/")[1] for x in lab], fontsize=5.6, rotation=90)
for j, dd in enumerate(["21 d", "63 d", "126 d", "252 d"]):
    a.text(3*j+1, 1.35e-4, dd, ha="center", fontsize=6.5, color=GRAY)
a.set_ylim(1e-4, 1.5); a.set_xlabel("strike (% of spot), by maturity"); a.set_ylabel("absolute error (index points)")
a.legend(loc="upper left", ncol=2, fontsize=6.2)
tag(a, "(c) Errors for all 24 options")
fig.savefig(FIGURES / "fig14_accuracy_cost.pdf")

# ---------------- Figure 3: bank impact and forecasts ----------------
fig, ax = plt.subplots(1, 2, figsize=(W, 2.75), gridspec_kw=dict(wspace=0.55, width_ratios=[1, 1.15]))
o = np.argsort(share)
a = ax[0]
cols = [BLUE if constituent[i] else GRAY for i in o]
a.barh(np.arange(12), 100*share[o], color=cols, height=0.65)
for k, i in enumerate(o): a.text(100*share[i]+0.4, k, f"{100*share[i]:.1f}", va="center", fontsize=6.5)
a.set_yticks(np.arange(12)); a.set_yticklabels([banks[i] for i in o], fontsize=7)
cum = np.cumsum(share[np.argsort(-share)])
a.set_xlabel("share of the quantum Fisher information (%)"); a.set_xlim(0, 27)
a.legend(handles=[Patch(color=BLUE, label="SX7E constituent"), Patch(color=GRAY, label="non-member (statistical stand-in)")], loc="lower right")
tag(a, "(a) Which banks drive the index option")

# 63-session forecasts (Supplementary Table S21): now, forecast, 90% interval
fc = {x["name"]: tuple(float(x[k]) for k in ("now_pct_spot", "forecast_63d_pct_spot", "pi90_low", "pi90_high"))
      for x in read_csv(PAPER_TABLES / "forecast_63d.csv")}
names = list(fc)[::-1]
a = ax[1]
for k, nm in enumerate(names):
    now, f63, lo, hi = fc[nm]; c = INK if "SX7E" in nm else BLUE
    a.plot([lo, hi], [k, k], color=c, lw=0.8, alpha=0.45)
    a.plot([now, f63], [k, k], color=c, lw=1.4)
    a.plot(now, k, "o", mfc="white", color=c, ms=3.6)
    a.plot(f63, k, "o", color=c, ms=3.6)
a.set_yticks(np.arange(len(names))); a.set_yticklabels(names, fontsize=7)
a.get_yticklabels()[-1].set_fontweight("bold")
a.plot([], [], "o", mfc="white", color=BLUE, ms=3.6, label="now (20 Oct 2026)")
a.plot([], [], "o", color=BLUE, ms=3.6, label="63-session forecast")
a.plot([], [], color=BLUE, lw=0.8, alpha=0.45, label="90% interval")
a.set_xlabel("3-month ATM call value (% of spot)"); a.set_xlim(2.5, 14.5)
a.legend(loc="upper right", fontsize=6.3)
tag(a, "(b) Forecast option values (63 sessions)")
fig.savefig(FIGURES / "fig15_banks_forecast.pdf")

# ---------------- Figure 4: robustness and contract design ----------------
fig, ax = plt.subplots(1, 2, figsize=(W, 2.35), gridspec_kw=dict(wspace=0.42, width_ratios=[1, 1.25]))
t6 = read_csv(PAPER_TABLES / "table6_qfi_rank_by_model.csv")    # Table 6
models = [x["model"] for x in t6]
floor_val = lambda s: 1e-16 if s.startswith("<") else float(s)   # "<1e-15" = round-off floor
l2 = [floor_val(x["lambda2_over_lambda1"]) for x in t6]
l3 = [floor_val(x["lambda3_over_lambda1"]) for x in t6]
stable = [int(x["stable_directions"]) for x in t6]
a = ax[0]; xi = np.arange(len(models))
a.axhspan(1e-17, 1e-15, color=GRAY, alpha=0.15, lw=0)
a.text(9.0, 1.2e-16, "round-off\nfloor", fontsize=6.0, color="#555", ha="center", va="center")
a.semilogy(xi, l2, "o", color=RED, ms=4, label="$\\lambda_2/\\lambda_1$ (second direction)")
a.semilogy(xi, l3, "D", color=PURPLE, ms=3, label="$\\lambda_3/\\lambda_1$ (third direction)")
for k in xi: a.text(k, 2e-4, str(stable[k]), ha="center", fontsize=6.8, color=INK)
a.text(-0.4, 3e-3, "number of stable directions", fontsize=6.3, color="#555")
a.set_xticks(xi); a.set_xticklabels(models); a.set_ylim(1e-17, 1e-1)
a.axvline(5.5, color=GRAY, lw=0.5, ls=":")
a.set_ylabel("eigenvalue relative to the largest"); a.legend(loc="center left", bbox_to_anchor=(0, 0.55))
tag(a, "(a) Extra bank directions are tiny")

t7 = {x["plan"]: x for x in read_csv(PAPER_TABLES / "table7_measurement_plans.csv")}   # Table 7
keys = ["ATM 63-day call", "Greek-based top four", "Random four (median of 500)", "Uniform all 72",
        "Classical D-optimal full space", "E-optimal on U", "+ digitals and binary strangles", "Score digitals (optimal)"]
plans = ["ATM 63-day call", "Greek-based top four", "Random four", "Uniform, all 72", "D-optimal, full space",
         "E-optimal on $U$", "+ digitals, binary strangles", "Score digitals (optimal)"]
m0 = [float(t7[k]["M0_pct"]) for k in keys]
c1 = [float(t7[k]["C1_pct"]) for k in keys]
a2 = [(float(t7[k]["A2_pct_low"]) + float(t7[k]["A2_pct_high"])) / 2 for k in keys]   # midpoint of seed range
a = ax[1]; yi = np.arange(len(plans))[::-1]; hgt = 0.26
floor = 0.01
for vals, off, c, nm in [(m0, hgt, INK, "M0 (baseline)"), (c1, 0, BLUE, "C1 (correlation regimes)"), (a2, -hgt, RED, "A2 (bank-specific vol.)")]:
    v = np.maximum(vals, floor)
    a.barh(yi+off, v-floor, height=hgt, color=c, alpha=0.85, label=nm, left=floor)
a.set_xscale("log"); a.set_xlim(floor, 600)
for off in (0, -hgt): a.text(0.012, yi[0]+off, "0", va="center", fontsize=5.8, color="#555")
a.set_yticks(yi); a.set_yticklabels(plans, fontsize=6.8)
a.axhline(1.5, color=GRAY, lw=0.5, ls=":")
a.set_xlabel("information per shot, % of the ceiling (weakest direction)")
a.legend(loc="center right", fontsize=6.3)
tag(a, "(b) Contract and payoff choice")
fig.savefig(FIGURES / "fig19_robustness_design.pdf")
print("saved figures/fig04, fig14, fig15, fig19")
