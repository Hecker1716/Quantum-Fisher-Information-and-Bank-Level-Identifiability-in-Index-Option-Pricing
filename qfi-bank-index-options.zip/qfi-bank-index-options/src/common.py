"""Shared model inputs, paths and Black-Scholes helpers for the SX7E twelve-bank proxy.

All inputs are read from data/inputs/ so the numbers live in one place:
  market_parameters.json  - spot, index volatility, rates, residual volatility
  bank_inputs.csv         - Table 1 (sigma_i, b_i, q_i) and Table 4 (QFI shares)
"""
import csv
import json
from pathlib import Path

import numpy as np
from scipy.stats import norm

# ---------------------------------------------------------------- paths
ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
INPUTS = DATA / "inputs"
PAPER_TABLES = DATA / "paper_tables"
DERIVED = DATA / "derived"
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
for _p in (DERIVED, RESULTS, FIGURES):
    _p.mkdir(parents=True, exist_ok=True)
RHO_FILE = DERIVED / "rho_one_factor.npy"

# ---------------------------------------------------------------- market parameters
_mp = json.loads((INPUTS / "market_parameters.json").read_text())
S0 = _mp["S0"]                              # SX7E close on 20 Oct 2026
sI = _mp["sigma_I"]                         # index volatility implied by Eq. (2)
r = float(np.log(1 + _mp["deposit_rate_annual"]))   # 2.47% continuous
q = _mp["q"]                                # 4.24% dividend yield
se = _mp["s_e"]                             # residual (tracking) volatility

# ---------------------------------------------------------------- bank inputs
with open(INPUTS / "bank_inputs.csv", encoding="utf-8") as f:
    _rows = list(csv.DictReader(f))
banks = [row["bank"] for row in _rows]
constituent = np.array([int(row["sx7e_constituent"]) for row in _rows], dtype=bool)
sig = np.array([float(row["sigma"]) for row in _rows])          # bank volatilities
b = np.array([float(row["loading_b"]) for row in _rows])        # ridge loadings, Eq. (1)
qi = np.array([float(row["dividend_yield"]) for row in _rows])  # bank dividend yields
share = np.array([float(row["qfi_share"]) for row in _rows])    # QFI shares, Table 4


def read_csv(path):
    """Read a CSV into a list of dicts (UTF-8)."""
    with open(path, encoding="utf-8") as f:
        return list(csv.DictReader(f))


def load_rho():
    """One-factor bank correlation matrix R0 (run calib.py first)."""
    if not RHO_FILE.exists():
        raise FileNotFoundError(f"{RHO_FILE} not found - run `python src/calib.py` first")
    return np.load(RHO_FILE)


# ---------------------------------------------------------------- Black-Scholes
def bs(S, K, T, s, r=r, q=q, call=True):
    """Black-Scholes price with continuous dividend yield."""
    d1 = (np.log(S / K) + (r - q + .5 * s * s) * T) / (s * np.sqrt(T))
    d2 = d1 - s * np.sqrt(T)
    if call:
        return S * np.exp(-q * T) * norm.cdf(d1) - K * np.exp(-r * T) * norm.cdf(d2)
    return K * np.exp(-r * T) * norm.cdf(-d2) - S * np.exp(-q * T) * norm.cdf(-d1)


def vega(S, K, T, s, r, q):
    """Black-Scholes vega."""
    d1 = (np.log(S / K) + (r - q + .5 * s * s) * T) / (s * np.sqrt(T))
    return S * np.exp(-q * T) * norm.pdf(d1) * np.sqrt(T)
