"""Calibrate the one-factor bank correlation matrix R0 (rho_ij = beta_i * beta_j).

The paper does not report the full bank correlation matrix, so (as in Section 4.5)
we calibrate a one-factor matrix that reproduces the index-volatility gradients
implied by the QFI shares in Table 4 and the index volatility sigma_I = 22.72%.
Output: data/derived/rho_one_factor.npy
"""
import numpy as np
from scipy.optimize import least_squares

from common import RHO_FILE, b, qi, r, se, sI, share, sig, vega

T = 63 / 252
nu = vega(1, 1, T, sig, r, qi)                 # bank ATM vegas (fraction of spot)
g = nu * np.sqrt(share)                        # d sigma_I / d sigma_i, up to scale
g *= sI * (1 - se**2 / sI**2) / np.sum(sig * g)  # fix the scale with Euler's identity
target = g * sI / b                            # (rho diag(sigma) b)_i
w = sig * b


def residual(beta):
    tot = np.sum(beta * w)
    return w + beta * (tot - beta * w) - target


sol = least_squares(residual, np.full(12, .8), bounds=(0, 0.999))
beta = sol.x
rho = np.outer(beta, beta)
np.fill_diagonal(rho, 1)
Sig = np.diag(sig) @ rho @ np.diag(sig)
off = rho[~np.eye(12, dtype=bool)]
print("factor loadings beta:", beta.round(3))
print(f"correlation range: {off.min():.2f} to {off.max():.2f}")
print(f"model sigma_I: {np.sqrt(b @ Sig @ b + se**2):.4f} (target {sI})")
print(f"max relative residual: {np.abs(sol.fun / target).max():.2e}")
np.save(RHO_FILE, rho)
print("saved", RHO_FILE.relative_to(RHO_FILE.parents[2]))
