"""Monte Carlo and QAE simulations for the SX7E twelve-bank proxy (63-day ATM call focus).

Produces the data behind Figures 3 and 14 of the paper (CMC paths, terminal law, convergence,
RMSE vs cost, cost at matched precision). Writes results/simulation_results.npz and
results/simulation_scalars.json. Runtime: a few minutes.
"""
import json

import numpy as np
from scipy.stats import norm, qmc

from common import RESULTS, S0, b, bs, load_rho, q, r, se, sI, sig
from qae import iqae

rho = load_rho()
L = np.linalg.cholesky(rho)
T63 = 63/252; K = S0
exact = bs(S0, K, T63, sI)
out = {"exact": exact}

# ---------- 12-bank CMC sampler ----------
def cmc_terminal(n, T, rng):
    Z = rng.standard_normal((n, 12)) @ L.T
    X = sig*np.sqrt(T)*Z
    eps = rng.standard_normal(n)*se*np.sqrt(T)
    return S0*np.exp((r-q-.5*sI**2)*T + X@b + eps)

# (1) sample paths, daily steps (13 normals per step)
rng = np.random.default_rng(7)
npath, nd = 10000, 63; dt = 1/252
Zd = rng.standard_normal((nd, npath, 12)) @ L.T
inc = (r-q-.5*sI**2)*dt + (sig*np.sqrt(dt)*Zd)@b + rng.standard_normal((nd, npath))*se*np.sqrt(dt)
paths = S0*np.exp(np.vstack([np.zeros(npath), np.cumsum(inc, 0)]))
out["paths_show"] = paths[:, :150]
out["paths_q"] = np.quantile(paths, [.05, .25, .5, .75, .95], axis=1)
out["paths_mean"] = paths.mean(1)
ST = paths[-1]
out["ST"] = ST
out["realised_sigma"] = float(np.std(np.log(ST/S0))/np.sqrt(T63))

# ---------- QAE grid (64 bins, +-4 sd, edge on strike, conditional means) ----------
def grid(T, K, n=6, w=4.0, call=True):
    m = np.log(S0) + (r-q-.5*sI**2)*T; s = sI*np.sqrt(T)
    lo, hi = m-w*s, m+w*s
    nb = 2**n; h = (hi-lo)/nb
    edges = lo + h*np.arange(nb+1)
    jK = np.argmin(np.abs(edges-np.log(K))); edges = edges + (np.log(K)-edges[jK])  # one edge exactly on the strike
    z = (edges-m)/s
    P = np.diff(norm.cdf(z)); p = P/P.sum()
    # conditional mean of S in each bin
    cm = np.exp(m+.5*s*s)*np.diff(norm.cdf(z-s))/P
    g = np.maximum(cm-K, 0) if call else np.maximum(K-cm, 0)
    # within-bin exact payoff expectation for vanilla (linear in S inside each bin since edge on K)
    return edges, p, cm, g

edges, p, cm, g = grid(T63, K)
gmin, gmax = g.min(), g.max()
f = (g-gmin)/(gmax-gmin)
a_true = float(p@f)
disc = np.exp(-r*T63)
grid_price = disc*(gmin+(gmax-gmin)*a_true)
Rg = disc*(gmax-gmin)
out.update(edges=edges, p=p, grid_price=grid_price, Rg=Rg)
sd_g = np.std(disc*np.maximum(cmc_terminal(10**6, T63, np.random.default_rng(1))-K, 0))
out["sd_g"] = sd_g
print(f"exact {exact:.4f} grid {grid_price:.4f} Rg {Rg:.3f} sd_g {sd_g:.3f} Rg/sd {Rg/sd_g:.1f}")

# (2) RMSE vs cost ------------------------------------------------------------
reps = 200
epss = np.geomspace(0.02, 0.0002, 9)
q_cost, q_rmse, q_G = [], [], []
for e in epss:
    rr = np.random.default_rng(int(e*1e7))
    res = [iqae(a_true, e, 0.05, 500, rr) for _ in range(reps)]
    est = np.array([disc*(gmin+(gmax-gmin)*x[0]) for x in res])
    q_rmse.append(np.sqrt(np.mean((est-exact)**2)))
    q_cost.append(np.mean([x[1] for x in res])); q_G.append(np.mean([x[2] for x in res]))
out.update(q_cost=np.array(q_cost), q_rmse=np.array(q_rmse), q_G=np.array(q_G), q_eps=epss)
r002 = [iqae(a_true, 0.002, 0.05, 500, np.random.default_rng(s)) for s in range(200)]
out["NA_eps002_median"] = float(np.median([x[1] for x in r002]))

Ns_c = np.unique(np.geomspace(1e2, 3e5, 10).astype(int))
c_rmse = []
rr = np.random.default_rng(11)
for n in Ns_c:
    reps_c = 200
    est = np.empty(reps_c)
    for i in range(reps_c):
        est[i] = disc*np.mean(np.maximum(cmc_terminal(n, T63, rr)-K, 0))
    c_rmse.append(np.sqrt(np.mean((est-exact)**2)))
out.update(c_cost=Ns_c.astype(float), c_rmse=np.array(c_rmse))
sl_c = np.polyfit(np.log(Ns_c), np.log(c_rmse), 1)[0]
sl_q = np.polyfit(np.log(q_cost), np.log(q_rmse), 1)[0]
sl_q_head = np.polyfit(np.log(q_cost[:6]), np.log(q_rmse[:6]), 1)[0]
out.update(sl_c=sl_c, sl_q=sl_q, sl_q_head=sl_q_head)
print("slopes CMC", sl_c, "QAE", sl_q, "QAE (first 6)", sl_q_head, "NA@0.002", out["NA_eps002_median"])

# (3) running CMC estimate with 95% CI --------------------------------------
rr = np.random.default_rng(2026)
payoff = disc*np.maximum(cmc_terminal(100000, T63, rr)-K, 0)
n = np.arange(1, len(payoff)+1)
run = np.cumsum(payoff)/n
run2 = np.cumsum(payoff**2)/n
se_run = np.sqrt(np.maximum(run2-run**2, 0)/n)
idx = np.unique(np.geomspace(50, len(payoff), 400).astype(int))-1
out.update(run_n=n[idx], run_mean=run[idx], run_se=se_run[idx])

# (4) cost to reach a target 95% half-width h -----------------------------------
hs = np.geomspace(0.01, 0.001, 6)
cost = {"Plain MC": [], "Antithetic + control variate": [], "Randomised QMC (1-D)": [], "QAE (IQAE)": []}
# plain MC: analytic from payoff sd
for h in hs: cost["Plain MC"].append((1.96*sd_g/h)**2)
# antithetic + CV: per-pair variance estimated by simulation (1-D law; same law as 12-bank model)
rr = np.random.default_rng(5)
Z = rr.standard_normal(10**6)
mu = (r-q-.5*sI**2)*T63; s = sI*np.sqrt(T63)
S1 = S0*np.exp(mu+s*Z); S2 = S0*np.exp(mu-s*Z)
Y = disc*.5*(np.maximum(S1-K, 0)+np.maximum(S2-K, 0))
C = disc*.5*(S1+S2); EC = S0*np.exp(-q*T63)
bcv = np.cov(Y, C)[0, 1]/np.var(C)
var_pair = np.var(Y-bcv*(C-EC))
for h in hs: cost["Antithetic + control variate"].append(2*(1.96**2*var_pair/h**2))
# RQMC scrambled Sobol: 32 randomisations; smallest 2^m with 1.96*sd <= h
rq_sd = {}
for m in range(4, 20):
    ests = []
    for sd in range(32):
        u = qmc.Sobol(1, scramble=True, seed=1000*m+sd).random_base2(m)[:, 0]
        ests.append(disc*np.mean(np.maximum(S0*np.exp(mu+s*norm.ppf(u))-K, 0)))
    rq_sd[2**m] = np.std(ests, ddof=1)
for h in hs:
    ok = [N for N, v in sorted(rq_sd.items()) if 1.96*v <= h]
    cost["Randomised QMC (1-D)"].append(ok[0] if ok else np.nan)
# QAE: sweep eps, record achieved 95% half-width (price units) and calls to A
q_hw, q_na = [], []
for e in np.geomspace(0.01, 0.00004, 12):
    rr = np.random.default_rng(int(e*1e8))
    res = [iqae(a_true, e, .05, 500, rr) for _ in range(50)]
    q_hw.append(np.median([Rg*x[4] for x in res])); q_na.append(np.median([x[1] for x in res]))
q_hw, q_na = np.array(q_hw), np.array(q_na)
o = np.argsort(q_hw)
cost["QAE (IQAE)"] = list(np.exp(np.interp(np.log(hs), np.log(q_hw[o]), np.log(q_na[o]))))
out["qsweep_hw"] = q_hw; out["qsweep_na"] = q_na
out["hs"] = hs
for kk, v in cost.items(): out["cost_"+kk] = np.array(v, float)
for kk, v in cost.items():
    v = np.array(v, float); ok = ~np.isnan(v)
    print(kk, np.round(v), "slope", np.polyfit(np.log(hs[ok]), np.log(v[ok]), 1)[0])
np.savez(RESULTS / "simulation_results.npz", **{k: np.asarray(v) for k, v in out.items()})
json.dump({k: float(v) for k, v in out.items() if np.ndim(v) == 0}, open(RESULTS / "simulation_scalars.json", "w"), indent=1)
print("saved results/simulation_results.npz and results/simulation_scalars.json")
